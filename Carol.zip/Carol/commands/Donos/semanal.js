module.exports = {
  name: "Semana",
  aliases: ["Semanal"],
  code:`
  $title[🌙 Bênção Semanal Ancestral]
  $description[✨ | Você invocou a bênção semanal das forças arcanas! Recebeu $random[100;10000] Cristais Ancestrais!

## Teu Tesouro Mágico
💫 | Seu poder total agora é $getUserVar[Cristal;$authorID] Cristais!]
 $color[#7B2CBF]
$cooldown[168h;
<:Undefinied:1451023424490311690> | Você já coletou Sua recompensa Semanal, volte em %time% Para coletar novamente!]
$seGlobalUserVar[Cristal;$sum[$getGlobalUserVar[Cristal;$authorID];$random[100;10000]]]`}