module.exports = {
  name: "help",
  aliases: ["ajuda", "comandos"],
  code: `👉 [MeuSite](https://f8b58683-6ef4-4554-a73a-7d2fc096bed4-00-2ykjvrk3bz868.riker.replit.dev/) — veja o help por lá!`
}