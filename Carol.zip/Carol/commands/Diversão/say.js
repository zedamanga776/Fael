module.exports = {
  name: "say",
  code: `
  $deletecommand
  $message`
}