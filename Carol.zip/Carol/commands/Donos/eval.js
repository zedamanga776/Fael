module.exports = {
  name: "eval",
  aliases: "e",
  code: `
  $deletecommand
  $eval[$message;false;true;true;false]
  $onlyForIds[$clientOwnerIds;]
  `
}