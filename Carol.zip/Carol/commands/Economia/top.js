module.exports = {
  name: "top",
  aliases: ["rank"],
  code: ` 
$title[👑 | Os 6 Maiores Acumuladores de Magia Arcana!]
$description[
:first_place: - $if[$splitText[1]==;Não listado;$splitText[1]]
:second_place: - $if[$splitText[2]==;Não listado;$splitText[2]]
:third_place: - $if[$splitText[3]==;Não listado;$splitText[3]]
:fourth_place: - $if[$splitText[4]==;Não listado;$splitText[4]]
:fifth_place: - $if[$splitText[5]==;Não listado;$splitText[5]]
:sixth_place: - $if[$splitText[6]==;Não listado;$splitText[6]]
]

$textSplit[$globalUserLeaderBoard[Cristal;desc;{tag} » {value};10];\n]
`
}