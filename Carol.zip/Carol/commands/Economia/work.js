module.exports = {
  name: "work",
  aliases: ["trabalhar", "trabalho"],
  code: `
  $title[⚡ Serviço à Magia]
  $description[$username[$authorID] serviu como $randomText[💻 Curandeiro Digital;📚 Guardião do Conhecimento;📱 Artesão de Dimensões;🚒 Protetor das Chamas;🚑 Curador Sagrado;👩‍🌾 Cultivador de Cristais;👩‍🚀 Navegador Cósmico],
  E sua recompensa mística foi: $random[100;3000] Cristais

  Mais um bônus de 3000 Cristais Arcanos!
  $color[#7B2CBF]
  
$setGlobalUserVar[Cristal;$sum[$getGlobalUservar[Cristal];$random[100;3000]]]
$setUserVar[Cristal;$sum[$getUserVar[Cristal];3000]

$cooldown[1h;<a:Undefinied2:1451205962454270126> | Você Já Trabalhou, Volte em %time% para Trabalhar Novamente!`
}