module.exports = {
name:"<@$clientID>",
aliases: ["<@!$clientID>"],
nonPrefixed: true,
code: `✨ Fael presente! Fui invocado através das dimensões.
🌀 Estou aqui para guiar você com minha magia ancestral.
📖 Use Fhelp para conhecer todos os meus encantamentos arcanos.`
}