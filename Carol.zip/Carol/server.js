const express = require("express");
const https = require("https");
const http = require("http");

const app = express();

app.get("/", (req, res) => {
  res.send("🟢 Bot online 24/7!");
});

app.get("/ping", (req, res) => {
  const url = req.query.url;
  if (!url) return res.send("❌ URL não informada");

  const lib = url.startsWith("https") ? https : http;

  const request = lib.get(url, r => {
    res.send(`🟢 Status: ONLINE (${r.statusCode})`);
  });

  request.on("error", () => {
    res.send("🔴 Status: OFFLINE");
  });

  request.setTimeout(10000, () => {
    request.destroy();
    res.send("⏰ Timeout");
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log("Servidor ligado na porta" + PORT);
});