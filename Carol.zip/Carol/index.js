require("./server");
const { AoiClient, LoadCommands } = require("aoi.js");

const client = new AoiClient({
  token: "MTQ1MDg3MjgxNDYyMTAzMjY0NA.Gimw45.l8nyCBb-rL_3OgHmqp5FfAQvePU5aiFIvuvxLw",
  prefix: "F",
  intents: ["MessageContent", "Guilds", "GuildMessages"],
  events: ["onMessage", "onInteractionCreate"],
  database: {
    type: "aoi.db",
    db: require("@akarui/aoi.db"),
    dbType: "KeyValue",
    tables: ["main"],
    securityKey: "a8387ff68d9f05ba7505f8daa312542e",
  }
});

client.variables({
  Cristal: "0"
})

client.status({
    name: "🚀 | SEMPRE MELHORANDO A CADA DIA!",
    type: "PLAYING",
    time: 12
});

const loader = new LoadCommands(client);
loader.load(client.cmd, "./commands")