module.exports = {
  name: "daily",
  aliases: ["diária", "diário", "recompensa diária"],
  code:`
  $title[💎 Bênção Diária da Magia]
  $description[✨ | Você invocou a bênção mística de Fael! Recebeu $random[100;10000] Cristais Arcanos!

## Teu Tesouro Mágico
💫 | Seu poder total agora é $getUserVar[Cristal;$authorID] Cristais!]
 $color[#7B2CBF]
$cooldown[1d;
<:Undefinied:1451023424490311690> | Você já coletou Sua recompensa diária, volte em %time% Para coletar novamente!]
$setGlobalUserVar[Cristal;$sum[$getGlobalUserVar[Cristal;$authorID];$random[100;10000]]]`}