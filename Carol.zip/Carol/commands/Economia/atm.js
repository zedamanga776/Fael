module.exports = {
  name: "bal",
  aliases: ["atm", "balance", "saldo"],
  code: `💎 | $username[$authorID], teu poder mágico é de $getGlobalUserVar[Cristal;$authorID] Cristais Arcanos. Use F+top para ver quem mais se destaca entre os escolhidos!`
}