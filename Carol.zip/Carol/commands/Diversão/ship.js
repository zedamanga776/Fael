module.exports = {
  name: "ship",
  aliases: ["shipar"],
  code: `
⚡ A conexão mística entre $mentioned[1] ~✨~ $mentioned[2] é de $random[1;100]% de compatibilidade arcana!
`
}