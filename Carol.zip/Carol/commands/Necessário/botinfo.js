module.exports = {
  name: "bot-info",
  aliases: ["botinfo", "bot-info", "info"],
  code: `
$title[✨ Fael — O Espírito Misterioso ✨]

$description[
<:Undefinied4:1451363235528970313> **| Quem sou eu?**  
Salve! Eu sou o <@$clientID>, o **Fael**, um espírito arcano envolvido em energia mística. Nasci das sombras com poder bruto e inteligência aguçada, pronto para guiar seu servidor através da diversão e da prosperidade com minha magia ancestral.

━━━━━━━━━━━━━━━━━━━━━━  
📌 **Meus Poderes Arcanos**

👨‍💻 **Meu Criador:**  
• bahiano123hc  

🌀 **Minha Essência Mística:**  
• Forjado em **Aoi.js**  
• Encantamentos rápidos, precisos e implacáveis <:Undefinied5:1451364463776104559>

⚡ **Meu Refúgio:**  
• **Vertra Cloud** — dimensão de poder infinito  
• **Replit** — onde minha magia floresce <:Undefinied6:1451365373466116171>

━━━━━━━━━━━━━━━━━━━━━━  
💎 **Por que invocar Fael?**

✔️ Magia de economia sem limites  
✔️ Encantamentos de diversão e sabedoria  
✔️ Proteção mística e confiável  
✔️ Espírito brasileiro de verdade 🇧🇷  

🌊 **Fael — o espírito que transforma, guia e domina.**
]

$color[#7B2CBF]
`
}