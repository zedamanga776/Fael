module.exports = [
  {
    name: "ticket",
    aliases: ["painel"],
    code: `
$description[✨ Invoque o encantamento "Suporte" para abrir um portal de comunicação com meus sacerdotes!
$image[$userAvatar[$clientID]]
]

$addButton[1;Suporte;primary;Suporte;false]`
  },
  {
    name: "Suporte",
    type: "interaction",
    prototype: "button",
    code: `$interactionReply[✨️ Criando seu portal mágico...;{ephemeral:true}]
$createChannel[$guildID;ticket-$authorID;Text;true;]`
  },
  {
    name: "FecharTicket",
    type: "interaction",
    prototype: "button",
    code: `$interactionReply[⏳ Fechando o portal em 3 segundos...;{ephemeral:true}]
$wait[3000]
$deleteChannel[$channelID]`
  }
]