module.exports = {
  name: "8ball",
  aliases: ["bola8", "bola", "8bola", "bola de cristal", "8", "bola"],
  code: `
$onlyIf[$message!=;<a:Undefinied2:1451205962454270126> Fale uma pergunta às minhas dimensões!]

✨ | > Tua pergunta: $message
🔮 | > Visão mística: $randomText[Sim, as energias confirmam;Não, as sombras negam;Talvez... a magia é incerta;Tente mais tarde, quando as estrelas se alinhem;Claro, com toda certeza;Não consigo enxergar;Minha magia falha agora;Invoque novamente quando os astros forem favoráveis]
  `
}